<?php include('header1.php'); ?>
<div class="wrapper">
<div class="title">Contact Us</div>
<div class="column column-1-4">
<img class="imgaa" src="pic/sandeep.jpg" width="100"> 
<div class="person-name">Sandeep Maharjan</div>
sandeepmaharjan55@gmail.com<br /> Baluwatar, Kathmandu
</div>

<div class="column column-1-4">
<img class="imgaa" src="pic/sanjeev.jpg" width="100"> 
<div class="person-name">Sanjeev Shrestha</div>
sanjeev.shrestha1995@hotmail.com<br /> Dhapakhel, Lalitpur</div>

<div class="column column-1-4">
<img class="imgaa" src="pic/saujan.jpg" width="100"> 
<div class="person-name">Saujan Rajbhandari</div>
rsauzan@gmail.com<br />SuryaBinayak, Bhaktapur</div>

<div class="column column-1-3">
<img class="imgaa" src="pic/srijina.jpg" width="100"> 
<div class="person-name">Srijana Dahal</div>
srijana.dahal12@gmail.com<br /> Gatthaghar, Bhaktapur</div>
</div>
<div style="clear:both"></div>

</div>
<?php include('footer.php'); ?>