<?php

$conn=@mysql_connect("mysql6.000webhost.com", "a3502683_agronep", "sandeepmaharjan");
@mysql_select_db('a3502683_agrodb',$conn);
?>