<div id="leftnav">
                	<ul>
                    	<li><a href="../admin/post.php">Post Manage</a></li>
                        <li><a href="../admin/product.php">Product Manage</a></li>
                        <li><a href="#">Contact Manage</a></li>
                        <li><a href="../admin/user.php">User Manage</a></li>
                    </ul>
                </div>
               
  