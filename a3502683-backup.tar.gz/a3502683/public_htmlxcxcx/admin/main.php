<?php include('./includes/sessionCheck.php'); ?>
<?php include('./header.php');?>
        <div id="right">
        <div id="title">Welcome to the Admin Panel</div>
        <div id="main">
        Welcome to the Admin Panel of Agro Nepal. Please do not close the browser without loging out. Thank you!
        </div>
        
        </div>
   </div>
   
  <div style="clear:both;"></div>
  <?php include('./footer.php'); ?>