<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
 <div id="footer">
   	CopyRight &copy; 2016. Agro Nepal<br />
  
   </div>
   </div>
</body>
</html>