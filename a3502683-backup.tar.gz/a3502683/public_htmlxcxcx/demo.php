<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


<head>

 
  

	
  
        
        
        <link rel="stylesheet" href="css/style1.css" type="text/css" media="screen" />
    
        
        
        <script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
        
        
       

<script src="js/tms-0.4.1.js"></script>
<script src="js/slider.js"></script>
        
        
    
</head>


<body> 




      <center>  
      <div class="photo">     
            
            
              
            
  <!-- Header -->
  <header>
  
    <div class="inner">
    
<div class="slider-container">
      <div class="mp-slider">
        <ul class="items">
          <li><img src="images/slide-1.jpg" alt="">
            <div class="banner mp-ban-1"><span class="row-1"><h1>A</h1></span><span class="row-2">helping hand for</span><span class="row-3"><h1>farmers</h1></span></div>
          </li>
          <li><img src="images/slide-2.jpg" alt="">
            <div class="banner mp-ban-2"><span class="row-1">AgroNepal</span></div>
          </li>
          <li><img src="images/slide-3.jpg" alt="">
            <div class="banner mp-ban-3"><span class="row-1"><h1>AgroNepal With You</h1></span><span class="row-2"><font size="3"  color="Green">God Made A Farmer</font></span></div>
            
          </li>
        </ul>
      </div>
    </div>

    
     
    <a href="#" class="mp-prev"></a> <a href="#" class="mp-next"></a> </header>
  <!-- Content -->
  <section id="content">
    <div class="container_24">
      <div class="wrapper">
        <div class="grid_24 content-bg">
          <div class="wrapper">
            <div class="grid_16 suffix_1 prefix_1 alpha">
              <article class="indent-bot">
              </div>
            
            
            </div></div></div>
            
            
            </div>  
            
            
                
            </center>
          
      
</body>
</html>
