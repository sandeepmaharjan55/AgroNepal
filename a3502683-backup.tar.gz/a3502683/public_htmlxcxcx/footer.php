<div class="footer">
        <div class="footer-wrapper">
            <div class="footer_contact">
            <h1>"A helping hand for farmer"</h1>
               
            </div>
            <div class="map">
            	<img src="pic/agr1.jpg" /></a>
            </div>
        </div>
        <div class="more_info">
        	<div class="more_info-wrapper">
            <div class="copyright">
                         Copyright &copy; 2016             
            </div>
                 <div class="footer_nav">
                    <ul>
    					<li ><a href="index.php">Home</a></li>
    					                        <li><a href="about_us.php">About Us</a></li>
    					
                       	<li><a href="contact_us.php">Contact Us</a></li>
 					 </ul>
                  </div>
            </div>
        </div>
	</div>
    
</body>
</html>