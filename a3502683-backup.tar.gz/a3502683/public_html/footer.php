<div class="footer">
        <div class="footer-wrapper">
            <div class="footer_contact">
            <h1>"A helping hand for farmer"</h1>
               
            </div>
            <div class="map">
            	<img src="pic/agr1.jpg" /></a>
            </div>
        </div>
        <div class="more_info">
        	<div class="more_info-wrapper">
            <div class="copyright">
                         Copyright &copy; 2016             
            </div>
                 <div class="footer_nav">
                    <ul>
    					<li ><a href="index.php">Home</a></li>
    					                        <li><a href="about_us.php">About Us</a></li>
    					
                       	<li><a href="contact_us.php">Contact Us</a></li>
 					 </ul>
                  </div>
            </div>
        </div>
	</div>
<!-- START OF HIT COUNTER CODE --><br><script language="JavaScript" src="http://www.counter160.com/js.js?img=1"></script><br><a href="https://www.000webhost.com"><img src="http://www.counter160.com/images/1/left.png" alt="Free web hosting" border="0" align="texttop"></a><a href="http://www.hosting24.com"><img alt="Web hosting" src="http://www.counter160.com/images/1/right.png" border="0" align="texttop"></a><!-- END OF HIT COUNTER CODE -->

    
</body>
</html>