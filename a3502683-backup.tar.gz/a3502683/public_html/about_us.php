<?php
	require_once('auth.php');
?>
<?php include('header1.php'); ?>
<div class="wrapper">
<div class="title">
About Us
</div>

<div class="content_body">
<div class="bolder">Its okay to make a mess,experiments can lead to beautiful things.</div>

<div class="bo">
<div class="st">OUR STORY</div>
</div>

<p>The food production is one of major global problems and although there is a lot of effort present to fix that problem, the progress is too slow. There is a huge lack of knowledge within producers all around the world in how to make their production effective and sustainable. The consequences of that are shocking numbers about hunger, production efficiency and natural resources exploit.</p>
<p>We believe that knowledge must be available to all agriculture producers and with help of intelligent but affordable technology, they can make significant change and improve their production. Driven by our beliefs, we are creating an intelligent and knowledge-based farm management site that helps farmers.</p>


<div class="su-callout">
<div class="callout-content">
<div class="custom-list"><strong>NUMBERS</strong></div>
<div class="custom-list">7.1 billion people live on the Earth</div>
<div class="custom-list">842 million people are starving every day</div>
<div class="custom-list">7 calories of input is needed for 1 calorie of food</div>
<div class="custom-list">70% of extracted fresh water is used for agriculture</div>
<div class="custom-list">50% of produced food is wasted</div>
<div class="custom-list">Population will reach 10 billion till 2050.</div>
<div class="spacer" style="height:15px"></div>
<div class="greendiv">THINGS MUST CHANGE.</div>
</div>
<div class="clear"></div>
</div>

<div class="bo">
<div class="st">TEAM</div>
</div></div>
<div class="column column-1-4">
<img class="imgaa" src="pic/sandeep.jpg" width="100"> 
<div class="person-name">Sandeep</div></div>

<div class="column column-1-4">
<img class="imgaa" src="pic/sanjeev.jpg" width="100"> 
<div class="person-name">Sanjeev</div></div>

<div class="column column-1-4">
<img class="imgaa" src="pic/saujan.jpg" width="100"> 
<div class="person-name">Saujan</div></div>

<div class="column column-1-4">
<img class="imgaa" src="pic/srijina.jpg" width="100"> 
<div class="person-name">Srijina</div></div>
</div>
<div style="clear:both"></div>
<?php include('footer.php'); ?>